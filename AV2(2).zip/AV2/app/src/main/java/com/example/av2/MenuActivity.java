package com.example.av2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MenuActivity extends AppCompatActivity {

    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu);


        button = (Button) findViewById(R.id.btCadastro);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openPerfil();
            }
        });

        button = (Button) findViewById(R.id.btPlaylists);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openPlaylists();
            }
        });
        }
    public void openPlaylists(){
        Intent intent = new Intent(this, ListaFilmes.class);
            startActivity(intent);
    }

    public void openPerfil(){
        Intent intent = new Intent(this, PerfilActivity.class);
        startActivity(intent);
    }


}