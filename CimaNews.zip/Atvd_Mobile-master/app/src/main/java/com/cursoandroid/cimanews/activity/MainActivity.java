package com.cursoandroid.cimanews.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.cursoandroid.cimatecmovie11.R;
import com.cursoandroid.cimanews.adapter.Adapter;
import com.cursoandroid.cimanews.classe.Filme;
import com.cursoandroid.cimanews.classe.Usuario;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Button botaoCadastrar;
    private RecyclerView recyclerView;
    private DatabaseReference reference = FirebaseDatabase.getInstance().getReference();

    List<Filme> listaFilmes;
    List<Usuario> listaUsuarios;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        botaoCadastrar = findViewById(R.id.buttonCadastrar);
        recyclerView = findViewById(R.id.recyclerView);
        listaFilmes = new ArrayList<>();
        listaUsuarios = new ArrayList<>();

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.addItemDecoration(new DividerItemDecoration(getApplicationContext(), LinearLayout.VERTICAL));


        botaoCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), TelaCadastro.class);
                startActivity(intent);
            }
        });


        DatabaseReference usuarios = reference.child("usuarios");

        usuarios.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                listaUsuarios.clear();

                for(DataSnapshot current_user:snapshot.getChildren()){
                    String id = current_user.getKey();
                    DatabaseReference user = usuarios.child(id);
                    DatabaseReference filmes = user.child("filmes");
                    filmes.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            for(DataSnapshot current_user:snapshot.getChildren()){
                                Usuario u = new Usuario();
                                String titulo = current_user.child("titulo").getValue().toString();
                                String ano = current_user.child("ano").getValue().toString();
                                int qntdCurtidas = Integer.parseInt(current_user.child("qntdCurtidas").getValue().toString());
                                Filme filme = new Filme(titulo,ano,qntdCurtidas);
                                u.setRA(Integer.parseInt(id));
                                u.setFilme(filme);
                                listaUsuarios.add(u);
                            }
                            Adapter adapter = new Adapter(listaUsuarios);
                            recyclerView.setAdapter(adapter);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }


}