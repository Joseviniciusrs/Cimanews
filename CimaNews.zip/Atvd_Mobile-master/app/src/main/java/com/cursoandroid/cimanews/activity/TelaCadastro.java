package com.cursoandroid.cimanews.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.cursoandroid.cimatecmovie11.R;
import com.cursoandroid.cimanews.classe.Filme;
import com.cursoandroid.cimanews.classe.Usuario;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class TelaCadastro extends AppCompatActivity {

    private DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
    private Button buttonEnviarCadastro, btnResetar, btnSair;
    private EditText editTextRA, editTextAno, editTextTitulo;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_cadastro);
        btnResetar = findViewById(R.id.btnResetar);
        buttonEnviarCadastro = findViewById(R.id.btnCadastrar);
        editTextRA = findViewById(R.id.editTextRa);
        editTextAno = findViewById(R.id.editTextAno);
        editTextTitulo = findViewById(R.id.editTextTitulo);

        DatabaseReference usuarios = reference.child("usuarios");


        btnResetar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextRA.setText("Insira o RA");
                editTextAno.setText("Insira o ano do filme");
                editTextTitulo.setText("Insira o título do filme");
            }
        });

        btnSair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        
        buttonEnviarCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Filme filme = new Filme();
                Usuario usuario = new Usuario();

                if(editTextTitulo.getText().toString().isEmpty()||editTextRA.getText().toString().isEmpty()||editTextAno.getText().toString().isEmpty()){
                    Toast.makeText(getApplicationContext(),"Preencha todos os campos",Toast.LENGTH_SHORT).show();
                }else{
                        usuario.setRA(Integer.parseInt(editTextRA.getText().toString()));
                        filme.setTitulo(editTextTitulo.getText().toString());
                        filme.setAno(editTextAno.getText().toString());
                        filme.setQntdCurtidas(0);
                        usuarios.child(String.valueOf(usuario.getRA())).child("filmes").push().setValue(filme);
                        Toast.makeText(getApplicationContext(), "Filme cadastrado", Toast.LENGTH_SHORT).show();
               }
            }
        });


    }

}