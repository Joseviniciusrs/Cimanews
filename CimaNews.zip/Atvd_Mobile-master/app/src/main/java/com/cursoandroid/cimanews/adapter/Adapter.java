package com.cursoandroid.cimanews.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.cursoandroid.cimanews.activity.MainActivity;
import com.cursoandroid.cimanews.classe.Usuario;
import com.cursoandroid.cimatecmovie11.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.MyViewHolder> {

    private DatabaseReference reference = FirebaseDatabase.getInstance().getReference();

    DatabaseReference usuarios = reference.child("usuarios");

    List<Usuario> ListaUsuarios = new ArrayList<>();
    public Adapter(List<Usuario> ListaUsuarios){
        this.ListaUsuarios = ListaUsuarios;
    }

    public Adapter() {

    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View filmeLista = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_adapter, parent, false);
        return new MyViewHolder(filmeLista);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        Usuario usuario = ListaUsuarios.get(position);
        holder.RA.setText(String.valueOf(usuario.getRA()));
        holder.titulo.setText(usuario.getFilme().getTitulo());
        holder.ano.setText(usuario.getFilme().getAno());
        holder.qntCurtidas.setText(String.valueOf(usuario.getFilme().getQntdCurtidas()));

    }

    @Override
    public int getItemCount() {
        return ListaUsuarios.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView titulo, RA, ano, qntCurtidas;
        Button botaoCurtir;

        Button btnVoltar;

        int curtidas = 0;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            titulo = itemView.findViewById(R.id.textTitulo);
            RA = itemView.findViewById(R.id.textRA);
            ano = itemView.findViewById(R.id.textAno);
            qntCurtidas = itemView.findViewById(R.id.textCurtidas);
            botaoCurtir = itemView.findViewById(R.id.botaoCurtir);


            botaoCurtir.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    curtidas++;
                    qntCurtidas.setText(String.valueOf(curtidas));

                }
            });

        }
    }
}
