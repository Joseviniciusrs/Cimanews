package com.cursoandroid.cimanews.classe;

public class Filme {

    private String titulo,ano;

    private int qntdCurtidas;


    public Filme(String titulo, String ano,int qntdCurtidas) {
        this.titulo = titulo;
        this.ano = ano;
        this.qntdCurtidas = qntdCurtidas;
    }

    public Filme(){

    }

    public String getTitulo() {

        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }


    public String getAno() {
        return ano;
    }

    public void setAno(String ano) {
        this.ano = ano;
    }

    public int getQntdCurtidas() {
        return qntdCurtidas;
    }

    public void setQntdCurtidas(int qntdCurtidas) {
        this.qntdCurtidas = qntdCurtidas;
    }
}
