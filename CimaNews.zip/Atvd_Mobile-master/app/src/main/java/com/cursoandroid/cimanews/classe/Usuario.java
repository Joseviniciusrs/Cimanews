package com.cursoandroid.cimanews.classe;

public class Usuario {

    private int RA;
    private Filme filme;

    public Usuario(int RA, Filme filme) {
        this.RA = RA;
        this.filme = filme;
    }

    public Usuario(){

    }

    public int getRA() {
        return RA;
    }

    public void setRA(int RA) {
        this.RA = RA;
    }

    public Filme getFilme() {
        return filme;
    }

    public void setFilme(Filme filme) {
        this.filme = filme;
    }
}
